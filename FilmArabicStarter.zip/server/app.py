import os
import tempfile
import subprocess
from pathlib import Path
from typing import List

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse
from openai import OpenAI

app = FastAPI(title="Film Arabic Subtitle API")
client = OpenAI()  # reads OPENAI_API_KEY from server environment

MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024  # illustrative limit: 2 GB


def run(cmd: List[str]) -> None:
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr[-4000:] or "External command failed")


def srt_time(seconds: float) -> str:
    ms = max(0, int(round(seconds * 1000)))
    hours, ms = divmod(ms, 3_600_000)
    minutes, ms = divmod(ms, 60_000)
    secs, ms = divmod(ms, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{ms:03}"


def translate_texts(texts: List[str]) -> List[str]:
    # Keep batches modest. For production, add retries, batching limits and glossary support.
    output: List[str] = []
    for start in range(0, len(texts), 30):
        batch = texts[start:start + 30]
        numbered = "\n".join(f"{i+1}. {t}" for i, t in enumerate(batch))
        response = client.chat.completions.create(
            model=os.getenv("TRANSLATION_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content":
                 "Translate each numbered subtitle segment into natural, concise Modern Standard Arabic. "
                 "Preserve meaning, names, tone, and numbering. Return only the numbered translations, one per line."},
                {"role": "user", "content": numbered},
            ],
            temperature=0.2,
        )
        raw = response.choices[0].message.content or ""
        lines = []
        for line in raw.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            # Remove the expected numeric prefix.
            import re
            stripped = re.sub(r"^\s*\d+[\).:\-]\s*", "", stripped)
            lines.append(stripped)
        if len(lines) != len(batch):
            raise RuntimeError("Translation model returned an unexpected number of lines; try again.")
        output.extend(lines)
    return output


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/translate-and-burn")
async def translate_and_burn(request: Request):
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(500, "OPENAI_API_KEY is not configured on the server")
    temp_dir = tempfile.mkdtemp(prefix="film_ar_")
    work = Path(temp_dir)
    video_path = work / "input_video"
    audio_path = work / "audio.mp3"
    srt_path = work / "arabic.srt"
    output_path = work / "translated_arabic.mp4"

    size = 0
    try:
        with video_path.open("wb") as f:
            async for chunk in request.stream():
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(413, "Video is too large for this demo server")
                f.write(chunk)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not receive video: {exc}")

    if size == 0:
        raise HTTPException(400, "Empty video upload")

    try:
        run(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1",
             "-ar", "16000", "-b:a", "48k", str(audio_path)])
        if audio_path.stat().st_size > 24 * 1024 * 1024:
            raise HTTPException(
                413,
                "Extracted audio exceeds the transcription endpoint size limit. "
                "Long-film chunking must be implemented for this file."
            )

        with audio_path.open("rb") as audio_file:
            transcription = client.audio.transcriptions.create(
                model=os.getenv("TRANSCRIPTION_MODEL", "whisper-1"),
                file=audio_file,
                response_format="verbose_json",
                timestamp_granularities=["segment"],
            )

        segments = getattr(transcription, "segments", None) or []
        if not segments:
            raise HTTPException(422, "No speech segments were detected")
        source_texts = [str(getattr(segment, "text", "")).strip() for segment in segments]
        arabic_texts = translate_texts(source_texts)

        with srt_path.open("w", encoding="utf-8-sig") as f:
            for i, (segment, text) in enumerate(zip(segments, arabic_texts), start=1):
                start = float(getattr(segment, "start", 0.0))
                end = float(getattr(segment, "end", start + 1.0))
                f.write(f"{i}\n{srt_time(start)} --> {srt_time(max(end, start + 0.2))}\n{text}\n\n")

        # FFmpeg subtitles filter burns the Arabic text into the picture.
        # libass and an Arabic-capable font must be installed on the server.
        escaped = str(srt_path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        run([
            "ffmpeg", "-y", "-i", str(video_path),
            "-vf", f"subtitles='{escaped}':force_style='FontName=Arial,FontSize=22,Outline=2,Shadow=1,Alignment=2,MarginV=36'",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
            str(output_path)
        ])
    except HTTPException:
        raise
    except FileNotFoundError as exc:
        raise HTTPException(500, "FFmpeg is not installed or not in PATH") from exc
    except Exception as exc:
        raise HTTPException(500, f"Processing failed: {str(exc)[:1200]}") from exc

    # FileResponse streams the output before TemporaryDirectory cleanup.
    from starlette.background import BackgroundTask
    import shutil
    return FileResponse(
        str(output_path),
        media_type="video/mp4",
        filename="translated_arabic.mp4",
        background=BackgroundTask(shutil.rmtree, temp_dir, ignore_errors=True),
    )
