package com.example.filmarabic

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var selectedVideo: Uri? = null
    private var outputUri: Uri? = null
    private lateinit var serverInput: EditText
    private lateinit var status: TextView
    private lateinit var translateButton: Button
    private lateinit var progress: ProgressBar

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            status.text = "تم اختيار الفيديو. اختر مكان حفظ النسخة المترجمة ثم اضغط ترجمة."
            translateButton.isEnabled = true
        }
    }

    private val createOutput = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) {
            outputUri = uri
            startTranslation()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }

        val title = TextView(this).apply {
            text = "مترجم الأفلام للعربية"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(title)

        val description = TextView(this).apply {
            text = "اختر ملف فيديو، ثم أرسله إلى خادم الترجمة. سيعود الفيديو بترجمة عربية محروقة داخل الصورة."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(description)

        serverInput = EditText(this).apply {
            hint = "عنوان الخادم، مثال: http://192.168.1.20:8000"
            setSingleLine(true)
            setText("http://10.0.2.2:8000")
        }
        root.addView(serverInput, LinearLayout.LayoutParams(-1, -2))

        val choose = Button(this).apply {
            text = "اختيار فيلم من الموبايل"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }
        root.addView(choose, LinearLayout.LayoutParams(-1, -2))

        translateButton = Button(this).apply {
            text = "ترجم واحرق الترجمة"
            isEnabled = false
            setOnClickListener {
                if (selectedVideo == null) {
                    toast("اختَر ملف فيديو أولًا")
                } else {
                    createOutput.launch("translated_arabic.mp4")
                }
            }
        }
        root.addView(translateButton, LinearLayout.LayoutParams(-1, -2))

        progress = ProgressBar(this).apply { visibility = android.view.View.GONE }
        root.addView(progress)

        status = TextView(this).apply {
            text = "جاهز. تأكد أن خادم الترجمة يعمل."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(status)

        val note = TextView(this).apply {
            text = "مهم: هذه النسخة تحتاج خادمًا وإنترنت. لا تضع مفتاح API داخل التطبيق. لا تنشر الخادم دون HTTPS ومصادقة."
            textSize = 12f
            setPadding(0, 24, 0, 0)
        }
        root.addView(note)

        setContentView(root)
    }

    private fun startTranslation() {
        val videoUri = selectedVideo ?: return
        val destination = outputUri ?: return
        val baseUrl = serverInput.text.toString().trim().trimEnd('/')
        if (!baseUrl.startsWith("http://") && !baseUrl.startsWith("https://")) {
            toast("أدخل عنوان خادم صحيحًا")
            return
        }

        translateButton.isEnabled = false
        progress.visibility = android.view.View.VISIBLE
        status.text = "جارٍ رفع الفيديو ومعالجته. قد يستغرق ذلك وقتًا حسب حجم الفيلم..."

        executor.execute {
            try {
                val conn = (URL("$baseUrl/translate-and-burn").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 30_000
                    readTimeout = 0
                    setRequestProperty("Content-Type", "application/octet-stream")
                    setRequestProperty("X-File-Name", "input-video")
                }

                // Send raw video bytes; the server endpoint accepts application/octet-stream.
                contentResolver.openInputStream(videoUri).use { input ->
                    requireNotNull(input) { "تعذر فتح ملف الفيديو" }
                    conn.outputStream.use { output -> input.copyTo(output, 1024 * 1024) }
                }

                val code = conn.responseCode
                if (code !in 200..299) {
                    val errorText = try { conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code" }
                                     catch (_: Exception) { "HTTP $code" }
                    throw IllegalStateException("الخادم أعاد خطأ: $errorText")
                }

                contentResolver.openOutputStream(destination, "w").use { output ->
                    requireNotNull(output) { "تعذر إنشاء ملف الناتج" }
                    conn.inputStream.use { input -> input.copyTo(output, 1024 * 1024) }
                }
                conn.disconnect()

                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    status.text = "اكتملت الترجمة وحُفظ الفيديو في المكان الذي اخترته."
                    translateButton.isEnabled = true
                    toast("تم حفظ الفيديو المترجم")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    status.text = "فشلت العملية: ${e.message ?: "خطأ غير معروف"}"
                    translateButton.isEnabled = true
                }
            }
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
